package com.example.florasg.Controller;

import java.util.List;

import com.example.florasg.Model.News;

public class NewsListRetriever {
	List<News> newsList;
	
	public List<News> getLatestNews () {
		
		return newsList;
		
	}
	
	public News getNewsItem (int news_ID){
		return null;
		
	}
}
